using System.Collections;
using UnityEngine;
using OscJack;

/// <summary>
/// ╔══════════════════════════════════════════════════════════╗
/// ║      MODE 2 — 다른 데스크탑 (Network / Remote IP)         ║
/// ║  Unity와 TouchDesigner가 서로 다른 컴퓨터에서 실행될 때    ║
/// ╚══════════════════════════════════════════════════════════╝
///
/// 특징:
///  · TD 컴퓨터의 IP 주소를 Inspector에서 직접 입력
///  · 하트비트(ping) 2초마다 → TD 연결 상태 자동 감지
///  · 연결 끊기면 자동 재연결 시도 (최대 10회)
///  · 연결 상태에 따라 전송 주기 자동 조정
///  · Unity → TD : 포트 9000 (Send)
///  · TD → Unity : 포트 9001 (Receive, 옵션)
///  · 네트워크 상태 : Disconnected → Connecting → Connected → Lost
///
/// 네트워크 설정 방법:
///  1. TD 컴퓨터의 IP 확인 (Windows: ipconfig / Mac: ifconfig)
///  2. 두 컴퓨터가 같은 Wi-Fi 또는 LAN에 연결되어 있어야 함
///  3. Inspector → Target IP에 TD 컴퓨터 IP 입력 (예: 192.168.0.10)
///  4. TD OSCin CHOP → Network Address: (비워두거나 * ), Port: 9000
///
/// TD 설정:
///  · OSCin CHOP  → Port: 9000 (Unity에서 오는 신호 수신)
///  · OSCout CHOP → Network Address: Unity 컴퓨터 IP, Port: 9001 (역방향)
/// </summary>
public class OSCSender_NetworkMode : MonoBehaviour
{
    public static OSCSender_NetworkMode Instance { get; private set; }

    // ── 네트워크 상태 ──────────────────────────────────────────
    public enum ConnectionState
    {
        Disconnected,   // 미연결 / 초기
        Connecting,     // 연결 시도 중
        Connected,      // 정상 연결
        Lost,           // 연결 끊김 (재연결 시도 중)
        Failed          // 최대 재시도 초과
    }

    // ── Inspector 설정 ────────────────────────────────────────
    [Header("▶ TD 컴퓨터 주소 (필수 입력)")]
    [Tooltip("TouchDesigner가 실행 중인 컴퓨터의 IP\n예) 192.168.0.10  /  10.0.0.5")]
    [SerializeField] private string targetIP   = "192.168.0.10";
    [SerializeField] private int    sendPort   = 9000;

    [Header("수신 (TD → Unity, 선택)")]
    [SerializeField] private bool enableReceive = true;
    [SerializeField] private int  receivePort   = 9001;

    [Header("연결 설정")]
    [SerializeField] private float sendInterval     = 0.033f; // ~30fps (네트워크 부하 고려)
    [SerializeField] private float heartbeatInterval = 2f;    // 하트비트 주기 (초)
    [SerializeField] private float heartbeatTimeout  = 6f;    // 이 시간 안에 응답 없으면 Lost
    [SerializeField] private int   maxRetries        = 10;    // 최대 재연결 시도 횟수

    [Header("디버그")]
    [SerializeField] private bool verboseLog = false;

    // ── 공개 상태 ─────────────────────────────────────────────
    public ConnectionState Status      { get; private set; } = ConnectionState.Disconnected;
    public bool            IsConnected => Status == ConnectionState.Connected;
    public int             RetryCount  { get; private set; }
    public float           LastPongTime{ get; private set; }
    public bool            TDReady     { get; private set; }

    // ── 이벤트 ────────────────────────────────────────────────
    public event System.Action<ConnectionState> OnStatusChanged;
    public event System.Action                  OnTDReady;
    public event System.Action<float>           OnTDBeat;
    public event System.Action<int>             OnTDScene;

    // ── 내부 ─────────────────────────────────────────────────
    private OscClient _sender;
    private OscServer _receiver;
    private float     _sendTimer;
    private float     _heartbeatTimer;
    private int       _lastStage = -1;
    private int       _lastState = -1;
    private bool      _waitingForPong;
    private Coroutine _reconnectRoutine;

    // ═══════════════════════════════════════════════════════════
    #region Unity 생명주기

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    void Start()
    {
        SetStatus(ConnectionState.Connecting);
        InitSender();
        if (enableReceive) InitReceiver();

        // 연결 확인 시작
        StartCoroutine(HeartbeatRoutine());
    }

    void Update()
    {
        // 메인 스레드 디스패치 처리
        UnityMainThreadNet.Flush();

        // TD가 꺼져 있어도 전송 시도 (재연결 감지용)
        _sendTimer += Time.deltaTime;
        if (_sendTimer >= sendInterval)
        {
            _sendTimer = 0f;
            SendExhibitionState();
        }
    }

    void OnDestroy()
    {
        if (_reconnectRoutine != null) StopCoroutine(_reconnectRoutine);
        try { _sender?.Dispose(); }   catch { }
        try { _receiver?.Dispose(); } catch { }
    }

    void OnGUI()
    {
        // 개발 중 화면에 연결 상태 표시 (빌드에서 제거하려면 #if UNITY_EDITOR 사용)
        #if UNITY_EDITOR
        GUIStyle style = new GUIStyle(GUI.skin.box);
        style.fontSize = 14;

        string label;
        Color  bgColor;
        switch (Status)
        {
            case ConnectionState.Connected:
                label   = $"● TD 연결됨  [{targetIP}:{sendPort}]";
                bgColor = new Color(0.1f, 0.6f, 0.1f, 0.85f);
                break;
            case ConnectionState.Connecting:
                label   = $"◌ 연결 중...  [{targetIP}:{sendPort}]";
                bgColor = new Color(0.6f, 0.5f, 0f, 0.85f);
                break;
            case ConnectionState.Lost:
                label   = $"! 연결 끊김  재시도 {RetryCount}/{maxRetries}";
                bgColor = new Color(0.7f, 0.2f, 0f, 0.85f);
                break;
            case ConnectionState.Failed:
                label   = $"✕ 연결 실패  IP 확인 필요";
                bgColor = new Color(0.5f, 0f, 0f, 0.85f);
                break;
            default:
                label   = "— TD 미연결";
                bgColor = new Color(0.3f, 0.3f, 0.3f, 0.85f);
                break;
        }

        GUI.backgroundColor = bgColor;
        GUI.Box(new Rect(10, 10, 280, 30), label, style);
        GUI.backgroundColor = Color.white;
        #endif
    }

    #endregion

    // ═══════════════════════════════════════════════════════════
    #region 초기화

    private void InitSender()
    {
        try
        {
            _sender = new OscClient(targetIP, sendPort);
            Debug.Log($"[OSC-Net] 전송 준비 → {targetIP}:{sendPort}");
        }
        catch (System.Exception e)
        {
            Debug.LogWarning($"[OSC-Net] 전송 초기화 실패: {e.Message}");
            SetStatus(ConnectionState.Failed);
        }
    }

    private void InitReceiver()
    {
        try
        {
            _receiver = new OscServer(receivePort);

            _receiver.MessageDispatcher.AddCallback("/td/pong",   OnReceivePong);
            _receiver.MessageDispatcher.AddCallback("/td/ready",  OnReceiveTDReady);
            _receiver.MessageDispatcher.AddCallback("/td/beat",   OnReceiveTDBeat);
            _receiver.MessageDispatcher.AddCallback("/td/scene",  OnReceiveTDScene);
            _receiver.MessageDispatcher.AddCallback("/td/custom", OnReceiveTDCustom);

            Debug.Log($"[OSC-Net] 수신 대기 ← 포트 {receivePort}");
        }
        catch (System.Exception e)
        {
            Debug.LogWarning($"[OSC-Net] 수신 초기화 실패: {e.Message}");
        }
    }

    #endregion

    // ═══════════════════════════════════════════════════════════
    #region 하트비트 / 연결 감지

    /// <summary>
    /// 주기적으로 /ping 전송 → TD가 살아있으면 /td/pong 응답
    /// 응답 없으면 Lost 처리 후 재연결
    /// </summary>
    private IEnumerator HeartbeatRoutine()
    {
        while (true)
        {
            yield return new WaitForSeconds(heartbeatInterval);

            // ping 전송
            _waitingForPong = true;
            SendRaw("/ping", 1);

            // timeout 대기
            float waited = 0f;
            while (_waitingForPong && waited < heartbeatTimeout)
            {
                waited += Time.deltaTime;
                yield return null;
            }

            if (_waitingForPong)
            {
                // 응답 없음
                if (Status == ConnectionState.Connected)
                {
                    Debug.LogWarning($"[OSC-Net] TD 응답 없음 → Lost");
                    SetStatus(ConnectionState.Lost);
                }

                RetryCount++;
                if (RetryCount >= maxRetries)
                {
                    Debug.LogError($"[OSC-Net] 최대 재시도 초과 ({maxRetries}회) → IP [{targetIP}] 확인 필요");
                    SetStatus(ConnectionState.Failed);
                    yield break;
                }

                // 재연결: 클라이언트 재생성
                Debug.Log($"[OSC-Net] 재연결 시도 {RetryCount}/{maxRetries}...");
                try { _sender?.Dispose(); } catch { }
                yield return new WaitForSeconds(1f);
                InitSender();
            }
            else
            {
                // 응답 받음 → 연결 확인
                if (Status != ConnectionState.Connected)
                {
                    RetryCount = 0;
                    SetStatus(ConnectionState.Connected);
                    Debug.Log($"[OSC-Net] ✓ TD 연결 확인 [{targetIP}:{sendPort}]");
                }
            }

            _waitingForPong = false;
        }
    }

    private void OnReceivePong(string address, OscDataHandle data)
    {
        LastPongTime    = Time.time;
        _waitingForPong = false;
        if (verboseLog) Debug.Log("[OSC-Net] ← pong 수신");
    }

    #endregion

    // ═══════════════════════════════════════════════════════════
    #region 전시 상태 자동 전송

    private void SendExhibitionState()
    {
        if (_sender == null) return;

        var em = ExhibitionManager.Instance;
        if (em == null) return;

        try
        {
            int stage = em.PanelIndex;
            int state = (int)em.CurrentState;

            if (stage != _lastStage)
            {
                SendRaw("/exhibition/stage", stage);
                _lastStage = stage;
                if (verboseLog) Debug.Log($"[OSC-Net] → stage {stage}");
            }
            if (state != _lastState)
            {
                SendRaw("/exhibition/state", state);
                _lastState = state;
                if (verboseLog) Debug.Log($"[OSC-Net] → state {state}");
            }

            var ti = GetComponent<TimerInteraction>();
            if (ti != null && ti.Running)
                SendRaw("/exhibition/timer", ti.Progress);
        }
        catch { /* 네트워크 오류 무시, HeartbeatRoutine이 처리 */ }
    }

    #endregion

    // ═══════════════════════════════════════════════════════════
    #region 공개 전송 API

    public void SendStageStart(int index)
    {
        SendRaw("/exhibition/stage/start", index);
        if (verboseLog) Debug.Log($"[OSC-Net] → StageStart {index}");
    }

    public void SendReelEvent()
    {
        SendRaw("/exhibition/reel/event", 1);
        if (verboseLog) Debug.Log("[OSC-Net] → ReelEvent");
    }

    public void SendClosing()
    {
        SendRaw("/exhibition/closing", 1);
        if (verboseLog) Debug.Log("[OSC-Net] → Closing");
    }

    public void SendInteractionZone(bool entering, int stageIndex)
    {
        SendRaw("/exhibition/interaction/zone",  entering ? 1 : 0);
        SendRaw("/exhibition/interaction/stage", stageIndex);
    }

    public void SendCustomFloat(string address, float value)  => SendRaw(address, value);
    public void SendCustomInt(string address, int value)      => SendRaw(address, value);

    /// <summary>
    /// Inspector에서 IP를 런타임 중 변경할 때 호출
    /// 예: 현장에서 TD 컴퓨터를 바꾸는 상황
    /// </summary>
    public void ChangeTargetIP(string newIP, int newPort = -1)
    {
        targetIP = newIP;
        if (newPort > 0) sendPort = newPort;

        RetryCount = 0;
        SetStatus(ConnectionState.Connecting);

        try { _sender?.Dispose(); } catch { }
        InitSender();

        Debug.Log($"[OSC-Net] 대상 변경 → {targetIP}:{sendPort}");
    }

    #endregion

    // ═══════════════════════════════════════════════════════════
    #region TD → Unity 수신 콜백

    private void OnReceiveTDReady(string address, OscDataHandle data)
    {
        TDReady = true;
        Debug.Log("[OSC-Net] ← TD Ready");
        UnityMainThreadNet.Post(() => OnTDReady?.Invoke());
    }

    private void OnReceiveTDBeat(string address, OscDataHandle data)
    {
        float bpm = data.GetElementAsFloat(0);
        if (verboseLog) Debug.Log($"[OSC-Net] ← TD Beat {bpm}");
        UnityMainThreadNet.Post(() => OnTDBeat?.Invoke(bpm));
    }

    private void OnReceiveTDScene(string address, OscDataHandle data)
    {
        int sceneIdx = data.GetElementAsInt(0);
        Debug.Log($"[OSC-Net] ← TD Scene {sceneIdx}");
        UnityMainThreadNet.Post(() => OnTDScene?.Invoke(sceneIdx));
    }

    private void OnReceiveTDCustom(string address, OscDataHandle data)
    {
        if (verboseLog) Debug.Log($"[OSC-Net] ← Custom: {address}");
    }

    #endregion

    // ═══════════════════════════════════════════════════════════
    #region 내부 헬퍼

    private void SetStatus(ConnectionState s)
    {
        if (Status == s) return;
        Status = s;
        Debug.Log($"[OSC-Net] 상태 변경 → {s}");
        UnityMainThreadNet.Post(() => OnStatusChanged?.Invoke(s));
    }

    private void SendRaw(string address, int value)
    {
        try { _sender?.Send(address, value); } catch { }
    }

    private void SendRaw(string address, float value)
    {
        try { _sender?.Send(address, value); } catch { }
    }

    #endregion
}

// ═══════════════════════════════════════════════════════════════
/// <summary>
/// NetworkMode 전용 메인 스레드 디스패처
/// (LocalMode의 UnityMainThread와 이름 충돌 방지)
/// </summary>
internal static class UnityMainThreadNet
{
    private static readonly System.Collections.Generic.Queue<System.Action> _queue
        = new System.Collections.Generic.Queue<System.Action>();
    private static readonly object _lock = new object();

    public static void Post(System.Action action)
    {
        lock (_lock) { _queue.Enqueue(action); }
    }

    public static void Flush()
    {
        while (true)
        {
            System.Action action;
            lock (_lock)
            {
                if (_queue.Count == 0) break;
                action = _queue.Dequeue();
            }
            action();
        }
    }
}
