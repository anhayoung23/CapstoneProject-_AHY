using UnityEngine;

/// <summary>
/// ╔══════════════════════════════════════════════════════════════╗
/// ║              TD 연결 모드 통합 매니저                          ║
/// ║  Inspector에서 모드 선택 → 해당 컴포넌트 자동 활성화            ║
/// ╠══════════════════════════════════════════════════════════════╣
/// ║  MODE_LOCAL   : Unity와 TD가 같은 컴퓨터                      ║
/// ║  MODE_NETWORK : Unity와 TD가 다른 컴퓨터 (IP 입력 필요)        ║
/// ╚══════════════════════════════════════════════════════════════╝
///
/// 사용법:
///  1. Managers 오브젝트에 이 컴포넌트 추가
///  2. Inspector → Connection Mode 선택
///  3. NetworkMode 선택 시 Target IP 입력
///  4. ExhibitionManager 등에서 TDConnectionManager.SendStageStart() 호출
///
/// 기존 OSCSender.cs와 공존 가능하지만,
/// ExhibitionManager의 OSCSender.Instance 호출을 이 클래스로 교체 권장.
/// </summary>
public class TDConnectionManager : MonoBehaviour
{
    public static TDConnectionManager Instance { get; private set; }

    // ── 모드 선택 ──────────────────────────────────────────────
    public enum ConnectionMode
    {
        [Tooltip("같은 컴퓨터 — IP 불필요, 양방향, 고속")]
        LocalMode,

        [Tooltip("다른 컴퓨터 — TD PC의 IP 입력, 하트비트 감지")]
        NetworkMode
    }

    [Header("▶ 연결 모드 선택")]
    [SerializeField] private ConnectionMode mode = ConnectionMode.LocalMode;

    [Header("Network 모드 전용 설정")]
    [Tooltip("TD가 실행 중인 컴퓨터 IP (NetworkMode일 때만 사용)")]
    [SerializeField] private string networkTargetIP = "192.168.0.10";

    // ── 내부 참조 ─────────────────────────────────────────────
    private OSCSender_LocalMode   _localSender;
    private OSCSender_NetworkMode _netSender;

    // ── 공개 상태 ─────────────────────────────────────────────
    public ConnectionMode ActiveMode => mode;

    public bool IsConnected =>
        mode == ConnectionMode.LocalMode
            ? true  // 로컬은 항상 "연결"로 간주
            : (_netSender != null && _netSender.IsConnected);

    public string StatusText =>
        mode == ConnectionMode.LocalMode
            ? "LOCAL (127.0.0.1)"
            : (_netSender != null ? $"{_netSender.Status}  [{networkTargetIP}]" : "—");

    // ═══════════════════════════════════════════════════════════
    #region Unity 생명주기

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    void Start()
    {
        ActivateMode();
    }

    #endregion

    // ═══════════════════════════════════════════════════════════
    #region 모드 전환

    private void ActivateMode()
    {
        // 기존 컴포넌트 정리
        var existingLocal = GetComponent<OSCSender_LocalMode>();
        var existingNet   = GetComponent<OSCSender_NetworkMode>();

        if (existingLocal != null) Destroy(existingLocal);
        if (existingNet   != null) Destroy(existingNet);

        if (mode == ConnectionMode.LocalMode)
        {
            _localSender = gameObject.AddComponent<OSCSender_LocalMode>();
            Debug.Log("[TDConn] ▶ LOCAL 모드 활성화 — 127.0.0.1:9000");
        }
        else
        {
            _netSender = gameObject.AddComponent<OSCSender_NetworkMode>();
            // IP 주입은 NetworkMode의 ChangeTargetIP로 처리
            // (Start 이전에 SerializedField가 반영되므로 Inspector 값 그대로 사용)
            Debug.Log($"[TDConn] ▶ NETWORK 모드 활성화 — {networkTargetIP}:9000");
        }
    }

    /// <summary>런타임 중 모드 전환 (현장 세팅 변경 시)</summary>
    public void SwitchMode(ConnectionMode newMode, string newIP = null)
    {
        mode = newMode;
        if (newIP != null) networkTargetIP = newIP;
        ActivateMode();
        Debug.Log($"[TDConn] 모드 전환 → {newMode}");
    }

    #endregion

    // ═══════════════════════════════════════════════════════════
    #region 공개 전송 API
    // ExhibitionManager에서 OSCSender.Instance 대신 이 클래스를 사용

    /// <summary>스테이지 시작 알림</summary>
    public void SendStageStart(int index)
    {
        if (mode == ConnectionMode.LocalMode)
            _localSender?.SendStageStart(index);
        else
            _netSender?.SendStageStart(index);
    }

    /// <summary>릴 감김 이벤트</summary>
    public void SendReelEvent()
    {
        if (mode == ConnectionMode.LocalMode)
            _localSender?.SendReelEvent();
        else
            _netSender?.SendReelEvent();
    }

    /// <summary>클로징 구간</summary>
    public void SendClosing()
    {
        if (mode == ConnectionMode.LocalMode)
            _localSender?.SendClosing();
        else
            _netSender?.SendClosing();
    }

    /// <summary>인터랙션 구간 진입/종료</summary>
    public void SendInteractionZone(bool entering, int stageIndex)
    {
        if (mode == ConnectionMode.LocalMode)
            _localSender?.SendInteractionZone(entering, stageIndex);
        else
            _netSender?.SendInteractionZone(entering, stageIndex);
    }

    /// <summary>임의 float 전송</summary>
    public void SendCustomFloat(string address, float value)
    {
        if (mode == ConnectionMode.LocalMode)
            _localSender?.SendCustomFloat(address, value);
        else
            _netSender?.SendCustomFloat(address, value);
    }

    /// <summary>임의 int 전송</summary>
    public void SendCustomInt(string address, int value)
    {
        if (mode == ConnectionMode.LocalMode)
            _localSender?.SendCustomInt(address, value);
        else
            _netSender?.SendCustomInt(address, value);
    }

    /// <summary>안내 상태 — 관람객에게 1면 관람 안내</summary>
    public void SendGuiding()   => SendCustomInt("/exhibition/guiding",    1);

    /// <summary>작품 설명 상태</summary>
    public void SendExplaining() => SendCustomInt("/exhibition/explaining", 1);

    #endregion

    // ═══════════════════════════════════════════════════════════
    #region GUI (Editor 전용 상태 표시)

    #if UNITY_EDITOR
    void OnGUI()
    {
        // NetworkMode의 OnGUI와 중복되지 않도록 LocalMode일 때만 표시
        if (mode != ConnectionMode.LocalMode) return;

        GUIStyle style    = new GUIStyle(GUI.skin.box) { fontSize = 14 };
        GUI.backgroundColor = new Color(0.1f, 0.4f, 0.8f, 0.85f);
        GUI.Box(new Rect(10, 10, 280, 30), $"● LOCAL  127.0.0.1:{9000}", style);
        GUI.backgroundColor = Color.white;
    }
    #endif

    #endregion
}
