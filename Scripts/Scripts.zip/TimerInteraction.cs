using System.Collections;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// (미사용) 타이머 컴포넌트 — 자동 진행 제거로 현재 비활성
/// </summary>
public class TimerInteraction : MonoBehaviour
{
    [Header("타이머")]
    [SerializeField] private float waitDuration = 3f;

    [Header("UI (선택)")]
    [SerializeField] private Image      timerFill;
    [SerializeField] private GameObject timerRoot;

    public float Progress { get; private set; }
    public bool  Running  { get; private set; }

    private Coroutine _routine;

    public void Begin()
    {
        if (_routine != null) StopCoroutine(_routine);
        Running  = true;
        Progress = 0f;
        if (timerRoot) timerRoot.SetActive(true);
        _routine = StartCoroutine(Tick());
    }

    public void Stop()
    {
        if (_routine != null) StopCoroutine(_routine);
        Running  = false;
        Progress = 0f;
        UpdateUI(0f);
        if (timerRoot) timerRoot.SetActive(false);
    }

    private IEnumerator Tick()
    {
        float elapsed = 0f;
        while (elapsed < waitDuration)
        {
            elapsed  += Time.deltaTime;
            Progress  = Mathf.Clamp01(elapsed / waitDuration);
            UpdateUI(Progress);
            yield return null;
        }
        Running = false;
        if (timerRoot) timerRoot.SetActive(false);
        // OnTimerExpired 제거됨 — 자동 진행 없음
    }

    private void UpdateUI(float v)
    {
        if (timerFill) timerFill.fillAmount = v;
    }
}
