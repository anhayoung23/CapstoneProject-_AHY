using UnityEngine;
using OscJack;

/// <summary>
/// Unity → TouchDesigner OSC 신호 전송
/// TD 꺼져있을 때도 에러 없이 동작
/// </summary>
public class OSCSender : MonoBehaviour
{
    public static OSCSender Instance { get; private set; }

    [Header("OSC 설정")]
    [SerializeField] private string targetIP    = "127.0.0.1";
    [SerializeField] private int    targetPort  = 9000;
    [SerializeField] private float  sendInterval = 0.05f;

    private OscClient _client;
    private float     _sendTimer;
    private int       _lastStage = -1;
    private int       _lastState = -1;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    void Start()
    {
        try
        {
            _client = new OscClient(targetIP, targetPort);
            Debug.Log($"[OSC] 전송 준비 → {targetIP}:{targetPort}");
        }
        catch (System.Exception e)
        {
            Debug.LogWarning($"[OSC] 클라이언트 생성 실패: {e.Message}");
        }
    }

    void Update()
    {
        if (_client == null) return;

        _sendTimer += Time.deltaTime;
        if (_sendTimer < sendInterval) return;
        _sendTimer = 0f;

        var em = ExhibitionManager.Instance;
        var ti = GetComponent<TimerInteraction>();
        if (em == null) return;

        try
        {
            int stage = em.PanelIndex;
            int state = (int)em.CurrentState;

            if (stage != _lastStage)
            {
                _client.Send("/exhibition/stage", stage);
                _lastStage = stage;
            }
            if (state != _lastState)
            {
                _client.Send("/exhibition/state", state);
                _lastState = state;
            }
            if (ti != null && ti.Running)
                _client.Send("/exhibition/timer", ti.Progress);
        }
        catch { /* TD 꺼져있으면 무시 */ }
    }

    void OnDestroy()
    {
        try { _client?.Dispose(); } catch { }
    }

    public void SendStageStart(int index)
    {
        try { _client?.Send("/exhibition/stage/start", index); }
        catch { }
    }

    public void SendReelEvent()
    {
        try { _client?.Send("/exhibition/reel/event", 1); }
        catch { }
    }

    public void SendClosing()
    {
        try { _client?.Send("/exhibition/closing", 1); }
        catch { }
    }
}
