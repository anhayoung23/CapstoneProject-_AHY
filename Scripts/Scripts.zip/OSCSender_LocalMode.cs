using UnityEngine;
using OscJack;

/// <summary>
/// ╔══════════════════════════════════════════════════════════╗
/// ║        MODE 1 — 같은 데스크탑 (Local / Localhost)         ║
/// ║  Unity와 TouchDesigner가 동일한 컴퓨터에서 실행될 때 사용   ║
/// ╚══════════════════════════════════════════════════════════╝
///
/// 특징:
///  · IP 고정 127.0.0.1 (변경 불필요)
///  · Unity → TD : 포트 9000  (Send)
///  · TD → Unity : 포트 9001  (Receive) ← 양방향
///  · 전송 주기 0.016s (≈60fps) — 로컬이므로 빠르게
///  · TD로부터 /td/ready, /td/beat 수신 가능
///  · TD가 꺼져 있어도 에러 없이 동작
///
/// TD 설정:
///  · TDAbleton 또는 OSCin CHOP → Network Address: localhost, Port: 9000
///  · OSCout CHOP → Network Address: localhost, Port: 9001 (Unity로 보낼 때)
///
/// 기존 OSCSender.cs 를 이 파일로 교체하거나 Inspector에서 선택하세요.
/// </summary>
public class OSCSender_LocalMode : MonoBehaviour
{
    public static OSCSender_LocalMode Instance { get; private set; }

    // ── 고정 설정 (같은 PC이므로 변경 불필요) ──────────────────
    private const string LOCAL_IP       = "127.0.0.1";
    private const int    SEND_PORT      = 9000;   // Unity → TD
    private const int    RECEIVE_PORT   = 9001;   // TD → Unity
    private const float  SEND_INTERVAL  = 0.016f; // ~60fps

    [Header("수신 활성화 (TD → Unity)")]
    [SerializeField] private bool enableReceive = true;

    [Header("디버그")]
    [SerializeField] private bool verboseLog = false;

    // ── 상태 ───────────────────────────────────────────────────
    public bool TDReady     { get; private set; }
    public bool TDBeat      { get; private set; }
    public int  TDSceneIndex{ get; private set; } = -1;

    // ── 이벤트 (TD가 신호를 보낼 때 구독 가능) ─────────────────
    public event System.Action         OnTDReady;
    public event System.Action<int>    OnTDScene;
    public event System.Action<float>  OnTDBeat;

    // ── 내부 ───────────────────────────────────────────────────
    private OscClient _sender;
    private OscServer _receiver;
    private float     _sendTimer;
    private int       _lastStage = -1;
    private int       _lastState = -1;

    // ═══════════════════════════════════════════════════════════
    #region Unity 생명주기

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    void Start()
    {
        InitSender();
        if (enableReceive) InitReceiver();
    }

    void Update()
    {
        _sendTimer += Time.deltaTime;
        if (_sendTimer < SEND_INTERVAL) return;
        _sendTimer = 0f;

        SendExhibitionState();
    }

    void OnDestroy()
    {
        try { _sender?.Dispose(); }   catch { }
        try { _receiver?.Dispose(); } catch { }
    }

    #endregion

    // ═══════════════════════════════════════════════════════════
    #region 초기화

    private void InitSender()
    {
        try
        {
            _sender = new OscClient(LOCAL_IP, SEND_PORT);
            Debug.Log($"[OSC-Local] ✓ 전송 준비 → {LOCAL_IP}:{SEND_PORT}");
        }
        catch (System.Exception e)
        {
            Debug.LogWarning($"[OSC-Local] 전송 초기화 실패: {e.Message}");
        }
    }

    private void InitReceiver()
    {
        try
        {
            _receiver = new OscServer(RECEIVE_PORT);

            // TD → Unity 수신 경로 등록
            _receiver.MessageDispatcher.AddCallback("/td/ready",  OnReceiveTDReady);
            _receiver.MessageDispatcher.AddCallback("/td/beat",   OnReceiveTDBeat);
            _receiver.MessageDispatcher.AddCallback("/td/scene",  OnReceiveTDScene);
            _receiver.MessageDispatcher.AddCallback("/td/custom", OnReceiveTDCustom);

            Debug.Log($"[OSC-Local] ✓ 수신 대기 ← 포트 {RECEIVE_PORT}");
        }
        catch (System.Exception e)
        {
            Debug.LogWarning($"[OSC-Local] 수신 초기화 실패: {e.Message}");
        }
    }

    #endregion

    // ═══════════════════════════════════════════════════════════
    #region 전시 상태 자동 전송 (매 프레임)

    private void SendExhibitionState()
    {
        if (_sender == null) return;

        var em = ExhibitionManager.Instance;
        if (em == null) return;

        try
        {
            int stage = em.PanelIndex;
            int state = (int)em.CurrentState;

            // 변경된 값만 전송 (불필요한 패킷 방지)
            if (stage != _lastStage)
            {
                _sender.Send("/exhibition/stage", stage);
                _lastStage = stage;
                if (verboseLog) Debug.Log($"[OSC-Local] → /exhibition/stage {stage}");
            }
            if (state != _lastState)
            {
                _sender.Send("/exhibition/state", state);
                _lastState = state;
                if (verboseLog) Debug.Log($"[OSC-Local] → /exhibition/state {state}");
            }

            // 타이머 진행도 (실행 중일 때만)
            var ti = GetComponent<TimerInteraction>();
            if (ti != null && ti.Running)
                _sender.Send("/exhibition/timer", ti.Progress);
        }
        catch { /* TD 꺼져있을 때 무시 */ }
    }

    #endregion

    // ═══════════════════════════════════════════════════════════
    #region 공개 전송 API (ExhibitionManager에서 호출)

    /// <summary>스테이지 시작 알림</summary>
    public void SendStageStart(int index)
    {
        Send("/exhibition/stage/start", index);
        if (verboseLog) Debug.Log($"[OSC-Local] → StageStart {index}");
    }

    /// <summary>릴 감김 이벤트</summary>
    public void SendReelEvent()
    {
        Send("/exhibition/reel/event", 1);
        if (verboseLog) Debug.Log("[OSC-Local] → ReelEvent");
    }

    /// <summary>클로징 구간 진입</summary>
    public void SendClosing()
    {
        Send("/exhibition/closing", 1);
        if (verboseLog) Debug.Log("[OSC-Local] → Closing");
    }

    /// <summary>인터랙션 구간 진입/종료</summary>
    public void SendInteractionZone(bool entering, int stageIndex)
    {
        Send("/exhibition/interaction/zone", entering ? 1 : 0);
        Send("/exhibition/interaction/stage", stageIndex);
    }

    /// <summary>임의 float 전송 (확장용)</summary>
    public void SendCustomFloat(string address, float value)
    {
        Send(address, value);
    }

    /// <summary>임의 int 전송 (확장용)</summary>
    public void SendCustomInt(string address, int value)
    {
        Send(address, value);
    }

    #endregion

    // ═══════════════════════════════════════════════════════════
    #region TD → Unity 수신 콜백

    private void OnReceiveTDReady(string address, OscDataHandle data)
    {
        TDReady = true;
        Debug.Log("[OSC-Local] ← TD Ready 수신");
        // 메인 스레드에서 이벤트 발생 (Unity API는 메인 스레드 필요)
        UnityMainThread.Post(() => OnTDReady?.Invoke());
    }

    private void OnReceiveTDBeat(string address, OscDataHandle data)
    {
        float bpm = data.GetElementAsFloat(0);
        TDBeat = true;
        if (verboseLog) Debug.Log($"[OSC-Local] ← TD Beat {bpm}");
        UnityMainThread.Post(() => OnTDBeat?.Invoke(bpm));
    }

    private void OnReceiveTDScene(string address, OscDataHandle data)
    {
        int sceneIdx = data.GetElementAsInt(0);
        TDSceneIndex = sceneIdx;
        Debug.Log($"[OSC-Local] ← TD Scene {sceneIdx}");
        UnityMainThread.Post(() => OnTDScene?.Invoke(sceneIdx));
    }

    private void OnReceiveTDCustom(string address, OscDataHandle data)
    {
        if (verboseLog) Debug.Log($"[OSC-Local] ← Custom: {address}");
    }

    #endregion

    // ═══════════════════════════════════════════════════════════
    #region 내부 헬퍼

    private void Send(string address, int value)
    {
        try { _sender?.Send(address, value); } catch { }
    }

    private void Send(string address, float value)
    {
        try { _sender?.Send(address, value); } catch { }
    }

    #endregion
}

// ═══════════════════════════════════════════════════════════════
/// <summary>
/// OSC 수신은 별도 스레드에서 오므로 Unity API 호출을 메인 스레드로 디스패치
/// </summary>
internal static class UnityMainThread
{
    private static readonly System.Collections.Generic.Queue<System.Action> _queue
        = new System.Collections.Generic.Queue<System.Action>();
    private static readonly object _lock = new object();

    public static void Post(System.Action action)
    {
        lock (_lock) { _queue.Enqueue(action); }
    }

    public static void Flush()
    {
        while (true)
        {
            System.Action action;
            lock (_lock)
            {
                if (_queue.Count == 0) break;
                action = _queue.Dequeue();
            }
            action();
        }
    }
}

/// <summary>
/// UnityMainThread.Flush()를 Update에서 호출해주는 헬퍼
/// Managers 오브젝트에 자동으로 붙어야 함
/// </summary>
internal class MainThreadDispatcher : MonoBehaviour
{
    private static MainThreadDispatcher _instance;

    public static void EnsureExists()
    {
        if (_instance != null) return;
        var go = new GameObject("MainThreadDispatcher");
        DontDestroyOnLoad(go);
        _instance = go.AddComponent<MainThreadDispatcher>();
    }

    void Update() => UnityMainThread.Flush();
}
